package com.softomotion.catalogs.main.presenter;

public class MainPressenterInterface<V extends > {
}
