package com.softomotion.catalogs.base;

public class BasePresenter<V extends View> implements Presenter<V> {

    private V mView;

    @Override
    public void onAttach(V mView) {
        mView = mView;
    }

    public V getmView(){
        return mView;
    }
}
