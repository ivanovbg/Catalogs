package com.softomotion.catalogs.base;

public interface View {
}
